from .physics import solve
